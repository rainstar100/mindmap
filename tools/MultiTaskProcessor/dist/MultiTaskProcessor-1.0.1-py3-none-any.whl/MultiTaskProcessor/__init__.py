# __init__.py

# Import any necessary modules or packages here

# Define any global variables or constants here

# Define any functions or classes here

# Optionally, include any initialization code here
# multi_thread_task_processor/__init__.py
from .processor import MultiThreadTaskProcessor

__all__ = ["MultiThreadTaskProcessor"]
